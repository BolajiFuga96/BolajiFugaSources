function e(t,n){return{customHTMLHeadEnd:`<!-- Google Tag Manager (noscript) -->
<noscript></noscript>`,customHTMLHeadStart:`<style>

::-webkit-scrollbar {
width: 0px;
height: 8px;
}

/* Set the background color of the scrollbar track */
::-webkit-scrollbar-track {
background-color: transparent;
}

/* Set the color and style of the scrollbar thumb */
::-webkit-scrollbar-thumb {
background-color: #00000017;
border-radius: 10px;
}

::-webkit-scrollbar-thumb:hover {
background-color: #00000040;
}

</style>
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-PCZXVRR8');<\/script>
<!-- End Google Tag Manager -->

<style>   /* Hide scrollbar for Chrome, Safari and Opera */   body::-webkit-scrollbar {     display: none;   }    /* Hide scrollbar for IE, Edge and Firefox */   body {     -ms-overflow-style: none;  /* IE and Edge */     scrollbar-width: none;  /* Firefox */   } </style>
<!-- Meta Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '818758106746740');
fbq('track', 'PageView');
<\/script>
<noscript></noscript>`,description:"Toolfolio helps you find the best tools for productivity, creativity, and design. Explore top solutions for startups, social media, AI, and more to optimize your workflow.",favicon:"https://framerusercontent.com/assets/9ByHhUNaWqyS1a9DYzxwg89yFG4.jpg",robots:"max-image-preview:large",socialImage:"https://framerusercontent.com/assets/wfMKZKJMRVUYAYzlRV8evfx01w.png",title:"Toolfolio - All the Tools You Need in One Place"}}export{e as a};
//# sourceMappingURL=chunk-3XGPAOSX.mjs.map
